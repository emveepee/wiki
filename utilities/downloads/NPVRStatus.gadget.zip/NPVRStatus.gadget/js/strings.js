// NextPVR Gadget v1.1

// These strings can be translated
var ERROR1 = "<div style=\"margin-left:10px\">NA - Check network connection, server, and settings.</div>";
var CONNECTING = "<div style=\"margin-left:10px\">Connecting...</div>";
var RECSCHEDULE = "Recording Schedule";
var REFRESH = "Click to refresh...";
var FREEDISK = "Free Disk Space";
var STATUS = "System Status";
var SCHEDULE = "Schedule";
var PENDING = " Pending, ";
var INPROGRESS = " In Progress, ";
var AVAILABLE = " Available<br/>";
var FAILED = " Failed, ";
var CONFLICTS = " Conflicts";
var RECURRING = " Recurring, ";
var DELETED = " Deleted";
var EPG = "EPG";
var ENDS = "Ends: ";
var DAYSLEFT = " days left";
var TUNERS = "Tuners";
var LOG = "Log";