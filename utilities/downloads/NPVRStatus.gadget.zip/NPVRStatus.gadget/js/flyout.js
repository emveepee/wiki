﻿// NextPVR Gadget v1.1

// Global variables
var gRecArray = null;
var gDF = "";
var gTF = "";
var gUrl = "";

function Init(recs, df, tf, url)
{
    gRecArray = recs;
    gTF = tf;
    gDF = df;
    gUrl = url;
}

// Generate the html for the Flyout
function FillFlyoutSchedule(showLogos)
{
    try
    {
        TITLE.innerText = RECSCHEDULE;

        if (gRecArray == null)
            return;

        // Generate HTML
        var htmlStr = "<table id=\"RECORDTABLE\">";
        var prevDate = "";
        var curDate = "";
        var now = new Date();
        
        for (var i = 0; i < gRecArray.length; i++)
        {
            // Group by day
            curDate = gRecArray[i].Start.format(gDF);
            if (curDate != prevDate)
            {
                htmlStr += "<tr><td class=\"DateRow\" colspan=\"4\">" + curDate + "</td></tr>";
                prevDate = curDate;
            }

            if (gRecArray[i].Status == "Recording")
                htmlStr += "<tr style=\"color:#FF0000\">";
            else
                htmlStr += "<tr>";

            if (gRecArray[i].Title != null)
            {
                htmlStr += "<td class=\"TimeColumn\">" + gRecArray[i].Start.format(gTF) + "<br/>- " + gRecArray[i].Stop.format(gTF) + "</td>";
                if (showLogos)
                    htmlStr += "<td class=\"ChLogoColumn\"><img class=\"ChLogoImg\" src=\"" + gRecArray[i].ChannelLogo + "\"></td>";
                var linkstr = " onclick=\"OpenBrowser('')\"";
                var hoverstr = " onmouseover=\"Underline(this)\" onmouseout=\"DeUnderline(this)\"";
                htmlStr += "<td class=\"ChannelColumn\">" + gRecArray[i].ChannelName + "<br/>" /*+ gRecArray[i].ChannelNumber */ + "</td>" + "<td class=\"TitleColumn\" title=\"" + gRecArray[i].Subtitle + ": " + gRecArray[i].Description + "\"" + linkstr + hoverstr + ">" + gRecArray[i].Title + "</td>";
            }
            htmlStr += "</tr>";
        }


        htmlStr += "</table>";

        FLYCONTENT.innerHTML = htmlStr;
        htmlStr = null;
    }
    catch (err)
    {
        // document.body.innerHTML = err.Description;
        ReportConnectionError();
    }

}

function FillSystemInfo(infoArray)
{
    try
    {
        TITLE.innerText = STATUS;
         
        var htmlStr = "";
        for (var i = 0; i < infoArray.length; i++)
        {
            htmlStr += "<div class='StatusHeader'>" + infoArray[i].name + "</div>";
            htmlStr += "<div class='StatusText'>" + infoArray[i].text + "</div>";
            htmlStr += "<br/>";
        }

        FLYCONTENT.innerHTML = htmlStr;
        htmlStr = null;
    }
    catch (err)
    {
        ReportConnectionError();
    }
}

function OpenBrowser( id)
{
    try
    {
        System.Shell.execute(gUrl + id, "");
    }
    catch (err)
    {
    }
}

function Underline( cell)
{
  cell.style.textDecoration = "underline";
}

function DeUnderline( cell)
{
  cell.style.textDecoration = "none";
}

function HighlightClient(cell)
{
    cell.style.backgroundColor = "#DDDDDD";
}

function UnHighlightClient(cell)
{
    cell.style.backgroundColor = "#E6F2FF";
}

function ReportConnectionError()
{
    FLYCONTENT.innerHTML = ERROR1;
}

