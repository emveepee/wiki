﻿// NextPVR Gadget v1.1

// Global variables
var gBackgroundImg = "\\images\\Background.jpg";
var gBorder = "";
var gServer = "server";
var gPort = "8866";
var gPIN = "0000"
var gUpdateMinutes = 5;
var gLaunchType = 0;
var gDateFormat = "ddd mmm dd";
var gTimeFormat = "h:MM TT";
var gNumRecs = 3;
var gTotalHeight = 145;
var gTotalWidth = 130;
var gShowDisk = true;
var gRecString = "\"<div class='RecordingTitle'>\" + rec.Title + \"</div><div class='RecordingSub'>\" + (isRecordingNow ? \"-\" + rec.Stop.format(gTimeFormat) : (date != today ? date : rec.Start.format(gTimeFormat))) + \" \" + rec.ChannelName + \"</div>\"";
var gXReq1 = null;
var gXReq2 = null;
var gXReq3 = null;
var gXReq4 = null;
var gRecArray = null;
var gShowLogos = false;
var gAddPadding = false;
var gInfoArray = null;
var gLastupdate = 0;

var gFailed = 0;
var gConflict = 0;
var gReady = 0;
var gInProgress = 0;
var gPending = 0;

// Constants
var gBaseHeight = 23;
var gHeaderHeight = 18;
var gRecHeight = 30;
var gDiskHeight = 60;
var gNRText = "------";
var SCHEDULE_URL = "/service?method=recording.list&filter=all";
var STATUS_URL = "/service?method=system.status";
var EPG_STATUS_URL = "/service?method=system.epg.summary";
var SPACE_URL = "/service?method=system.space";
var LOGS_URL = "/service?method=system.logs";
var LOGO_URL = "/service?method=channel.icon&channel_id=";

var DETAILS_URL = "/scheduler.html";
var NPVR_EXE = "\\NextPVR.exe";
var REG_INSTALL = "HKLM\\Software\\NPVR\\InstallDirectory";
var REG_INSTALL_64 = "HKLM\\Software\\Wow6432Node\\NPVR\\InstallDirectory";

function loadMain() {
    debugger;
    CURRENTHEADER.innerText = RECSCHEDULE;
    DISKHEADER.innerText = FREEDISK;

    // Setttings page
    System.Gadget.settingsUI = "settings.html";
    System.Gadget.onSettingsClosed = SettingsClosed;

    // Flyout
    System.Gadget.Flyout.file = "flyout.html";

    // Images
    gBackgroundImg = System.Gadget.path + gBackgroundImg;

    // Apply current settings
    gBorder = MAINCONTENT.style.borderStyle;
    ApplySettings();
}



function Launch() {
    switch (gLaunchType) {
        case 0:
            System.Shell.execute("http://" + gServer + ":" + gPort, "");
            break;
        case 1:
            System.Shell.execute(GetInstallDirFromReg() + NPVR_EXE, "");
            break;
    }
}

function ConnectToNPVR() {
    // Try to connect to Web Server
    CURRENT.innerHTML = CONNECTING;

    try {
        var sidReq = new XMLHttpRequest();
        sidReq.open("GET", "http://" + gServer + ":" + gPort + "/service?method=session.initiate&ver=1.0&device=gadget" + "&r=" + Math.ceil(Math.random() * 100000).toString(), false);
        sidReq.send(null);
        var doc = sidReq.responseXML;
        var sid = doc.getElementsByTagName("sid")[0].text;
        var salt = doc.getElementsByTagName("salt")[0].text;
        var sidReq = new XMLHttpRequest();
        var md5 = MD5(":" + MD5(gPIN) + ":" + salt);
        sidReq.open("GET", "http://" + gServer + ":" + gPort + "/service?method=session.login&md5=" + md5 + "&sid=" + sid + "&r=" + Math.ceil(Math.random() * 100000).toString(), false);
        sidReq.send(null);
        doc = sidReq.responseXML;
        sid = "&sid=" + sid;

        STATUS_URL = "/service?method=system.status" + sid;
        EPG_STATUS_URL = "/service?method=system.epg.summary" + sid;
        SPACE_URL = "/service?method=system.space" + sid;
        SCHEDULE_URL = "/service?method=recording.list&filter=all" + sid;
        LOGS_URL = "/service?method=system.logs" + sid;

        if (gXReq1 == null) {
            gXReq1 = new XMLHttpRequest();
            gXReq1.onreadystatechange = FillSchedule;
        } else if (gXReq1.readyState != 4)
            return;
        gXReq1.open("GET", "http://" + gServer + ":" + gPort + SCHEDULE_URL + "&r=" + Math.ceil(Math.random() * 100000).toString(), true);
        gXReq1.send();

    } catch (err) {
        ReportConnectionError();
        ReportConnectionError2();
        // CURRENT.innerHTML = err;
    }

}

function FillSchedule() {
    try {
        // Make sure it was properly loaded
        if (gXReq1.readyState != 4)
            return;

        gRecArray = null;
        var doc = gXReq1.responseXML;
        if (doc.documentElement == null)
            throw "Error";

        ProcessRecordingsXML(doc);
        // gRecArray.sort(sortRecordings);

        // List current recordings
        var sHTML = "";
        var now = new Date();
        var today = now.format(gDateFormat);
        for (var i = 0; i < gNumRecs; i++) {
            if (i < gRecArray.length && gRecArray[i] != null && gRecArray[i].Title != null) {
                try {
                    var rec = gRecArray[i];
                    var isRecordingNow = false
                    var date = gRecArray[i].Start.format(gDateFormat);
                    if (gRecArray[i].Status == "Recording") {
                        isRecordingNow = true;
                        sHTML += "<div class=\"RecordingText\" style=\"overflow:hidden;height:" + gRecHeight + "px\">";
                    } else if (gRecArray[i].Status == "Pending") {
                        sHTML += "<div style=\"overflow:hidden;height:" + gRecHeight + "px\">";
                    }
                    sHTML += eval('(' + gRecString + ')') + "</div>";
                } catch (err) {
                    sHTML += "<div class=\"RecordingTitle\">" + err.name + "</div>" + "<div class=\"RecordingSub\">" + err.description + "</div>";
                }
            } else {
                sHTML += "<div class=\"RecordingTitle\">" + gNRText + "</div>" + "<div class=\"RecordingSub\"></div>";
            }
        }


        CURRENT.innerHTML = sHTML;
        sHTML = null;

        // Disk space
        if (gShowDisk) {
            FillSystemStatus();
            FillEpgStatus();
            FillTunerStatus();

            var log = new Object();
            log.name = LOG;
            log.text = "<a href='" + "http://" + gServer + ":" + gPort + LOGS_URL + "'>Download Logs</a>";
            gInfoArray.push(log);
        }
    } catch (err) {
        ReportConnectionError();
        ReportConnectionError2();
        //      CURRENT.innerHTML = err;
    }
}

function ProcessRecordingsXML(doc) {

    try {
        if (gRecArray == null)
            gRecArray = new Array();

        gInProgress = 0;
        gFailed = 0;
        gConflict = 0;
        gReady = 0;
        gPending = 0;

        var nodes = doc.getElementsByTagName("recordings/recording");
        for (i = 0; i < nodes.length; i++) {
            var item = nodes.item(i);
            var status = item.selectSingleNode("status").text;
            switch (status) {
                case "Failed":
                    gFailed++;
                    continue;
                case "Conflict":
                    gConflict++;
                    continue;
                case "Ready":
                    gReady++;
                    continue;
                case "Recording":
                    gInProgress++;
                    break;
                case "Pending":
                    gPending++;
                    break;
                default:
                    continue;
            }
            var rec = new Object();
            rec.Title = item.selectSingleNode("name").text;
            rec.Description = item.selectSingleNode("desc").text;
            rec.Status = item.selectSingleNode("status").text;
            // also add period text
            rec.Start = new Date(Number(item.selectSingleNode("start_time_ticks").text) * 1000);
            rec.Stop = new Date(rec.Start.getTime() + (Number(item.selectSingleNode("duration_seconds").text) * 1000));
            if (gAddPadding) {
                var pad = item.selectSingleNode("pre_padding").text * 1;
                if (pad > 0)
                    rec.Start = new Date(rec.Start.getTime() - (pad * 60.0 * 1000.0));

                pad = item.selectSingleNode("post_padding").text * 1;
                if (pad > 0)
                    rec.Stop = new Date(rec.Stop.getTime() + (pad * 60.0 * 1000.0));
            }
            rec.ChannelName = item.selectSingleNode("channel").text;
            //rec.ChannelNumber =item.selectSingleNode("channel_id").text;
            rec.ChannelLogo = "http://" + gServer + ":" + gPort + LOGO_URL + item.selectSingleNode("channel_id").text;
            if (item.selectSingleNode("file"))
                rec.Filename = item.selectSingleNode("file").text;
            else
                rec.Filename = null;
            try {
                rec.Subtitle = item.selectSingleNode("subtitle").text;
                rec.oid = item.selectSingleNode("epg_event_oid").text;
                rec.rid = item.selectSingleNode("id").text;
            } catch (err) {

            }
            gNumRecs++;
            gRecArray.push(rec);
        }
    } catch (err) {
        //CURRENT.innerHTML = err;
    }
}

function UTCStringToDate(utc) {
    try {
        return new Date(Date.UTC(parseInt(utc.substr(0, 4), 10), parseInt(utc.substr(5, 2), 10) - 1, parseInt(utc.substr(8, 2), 10), parseInt(utc.substr(11, 2), 10), parseInt(utc.substr(14, 2), 10)));
    } catch (err) {
        return new Date();
    }
}

function sortRecordings(a, b) {
    if (a.Start < b.Start)
        return -1;
    else
        return 1;
}

function FillSystemStatus() {
    try {
        var XReq3 = new XMLHttpRequest();
        XReq3.open("GET", "http://" + gServer + ":" + gPort + SPACE_URL + "&r=" + Math.ceil(Math.random() * 100000).toString(), false);
        XReq3.send(null);
        var doc = XReq3.responseXML;
        var dirs = doc.getElementsByTagName("directory");
        var martin = dirs(0).getAttribute("name");
        if (dirs != null && dirs.length > 0 && dirs(0).getAttribute("name") == "Default") {
            var free = dirs(0).selectSingleNode("free").text;
            var total = dirs(0).selectSingleNode("total").text;
            var nfree = Number(free) / 1000000000;
            var ntotal = Number(total) / 1000000000;
            var ntotal = Number(total) / 1000000000;
            var used = 100 - nfree / ntotal * 100;

            DISKTEXT.innerText = nfree.toFixed(1).toString() + " / " + ntotal.toFixed(1).toString();
            DISKUSED.style.width = used.toFixed(1).toString() + "%";
        }

        gInfoArray = new Array();
        var sch = new Object();
        sch.name = SCHEDULE;
        sch.text = gPending.toString() + PENDING + gInProgress.toString() + INPROGRESS + gReady.toString() + AVAILABLE + gFailed.toString() + FAILED + gConflict.toString() + CONFLICTS;
        gInfoArray.push(sch);
    } catch (err) {
        ReportConnectionError2();
        //DISKTEXT.innerHTML = err;
    }
}

function FillTunerStatus() {
    try {
        var XReq4 = new XMLHttpRequest();
        XReq4.open("GET", "http://" + gServer + ":" + gPort + STATUS_URL + "&r=" + Math.ceil(Math.random() * 100000).toString(), false);
        XReq4.send(null);

        var doc = XReq4.responseXML;
        var dirs = doc.getElementsByTagName("Status");
        var tun = new Object();
        tun.name = TUNERS
        tun.text = "";
        var tuners = doc.getElementsByTagName("Device");
        for (var j = 0; j < tuners.length; j++) {
            if (j > 0)
                tun.text += "<br/>";
            tun.text += tuners[j].getAttribute("identifier") + " : ";
            var events = tuners[j].getElementsByTagName("Recording");
            for (var k = 0; k < events.length; k++) {
                var f = events[k].text;
                for (var i = 0; i < gRecArray.length && gRecArray[i] != null; i++) {
                    if (f == gRecArray[i].Filename) {
                        f = gRecArray[i].Title;
                        break;
                    }
                }
                tun.text += "<br/>- " + f;
            }
            var k1 = events.length;
            var re = /live-(.+?)-/;
            var events = tuners[j].getElementsByTagName("LiveTV");
            for (var k = 0; k < events.length; k++) {
                var f = events[k].text;
                var a = re.exec(f);
                if (a != null)
                    f = "Live: " + a[1];
                tun.text += "<br/>- " + f;
            }
            k1 += events.length;
            if (k1 == 0) tun.text += "Sleeping";


        }
        gInfoArray.push(tun);
    } catch (err) {
        ReportConnectionError2();
        //DISKTEXT.innerHTML = err;
    }
}

function FillEpgStatus() {
    try {
        var XReq2 = new XMLHttpRequest();
        XReq2.open("GET", "http://" + gServer + ":" + gPort + EPG_STATUS_URL + "&r=" + Math.ceil(Math.random() * 100000).toString(), false);
        XReq2.send(null);
        var doc = XReq2.responseXML;
        var dirs = doc.getElementsByTagName("furthest_listing");
        var tun = new Object();
        tun.name = TUNERS
        tun.text = "";
        var tuners = doc.getElementsByTagName("Device");
        var lastTime = Number(dirs[0].text) * 1000;
        var dt = new Date();
        var diffTime = Math.floor((lastTime - dt.getTime()) / (24 * 60 * 60 * 1000));
        gLastupdate = new Date(lastTime);
    } catch (err) {
        gLastupdate = new Date();
        diffTime = 0;
    }
    var epg = new Object();
    epg.name = EPG;
    epg.text = ENDS + gLastupdate.format(gDateFormat) + "<br/>" + diffTime + DAYSLEFT;
    gInfoArray.push(epg);

}

function ReportConnectionError() {
    CURRENT.innerHTML = ERROR1;
}

function ReportConnectionError2() {
    DISKTEXT.innerText = "NA";
    DISKUSED.style.width = "100%";
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
// For the options/settings

function SettingsClosed(event) {
    if (event.closeAction == event.Action.commit) {
        ApplySettings();
    }
}

function ApplySettings() {
    // If the settings aren't saved yet, write defaults, otherwise load them
    ReadLocalSettings()
    var str = System.Gadget.Settings.readString("Background");
    if (str == "")
        System.Gadget.Settings.write("Background", gBackgroundImg);
    else
        gBackgroundImg = str;

    str = System.Gadget.Settings.readString("Size");
    if (str == "")
        System.Gadget.Settings.writeString("Size", gNumRecs);
    else {
        try {
            gNumRecs = parseInt(str);
            if (gNumRecs < 1 || gNumRecs > 12)
                gNumRecs = 3;
        } catch (err) {
            gNumRecs = 3;
        }
    }

    str = System.Gadget.Settings.readString("Width");
    if (str == "")
        System.Gadget.Settings.writeString("Width", gTotalWidth);
    else {
        try {
            gTotalWidth = parseInt(str);
            if (gTotalWidth < 130 || gTotalWidth > 300)
                gTotalWidth = 130;
        } catch (err) {
            gTotalWidth = 130;
        }
    }

    str = System.Gadget.Settings.readString("ShowDisk");
    if (str == "")
        System.Gadget.Settings.write("ShowDisk", true);
    else
        gShowDisk = (str == "True" || str == "1");

    DISKCONTENT.style.display = gShowDisk ? "block" : "none";

    str = System.Gadget.Settings.readString("RecHeight");
    if (str == "")
        System.Gadget.Settings.writeString("RecHeight", gRecHeight);
    else {
        try {
            gRecHeight = parseInt(str);
            if (gRecHeight < 30 || gRecHeight > 200)
                gRecHeight = 30;
        } catch (err) {
            gRecHeight = 30;
        }
    }

    // Compute heights
    gTotalHeight = gBaseHeight + gHeaderHeight + gRecHeight * gNumRecs;
    if (gShowDisk)
        gTotalHeight += gDiskHeight;

    str = System.Gadget.Settings.readString("Margins");
    if (str == "") {
        System.Gadget.Settings.writeString("Margins", "0 0 0 0");
        MAINCONTENT.style.height = gTotalHeight;
    } else {
        try {
            var strings = str.split(" ");
            var margins = new Array(parseInt(strings[0]), parseInt(strings[1]), parseInt(strings[2]), parseInt(strings[3]));
            MAINCONTENT.style.margin = margins[0] + " " + margins[1] + " " + margins[2] + " " + margins[3];
            MAINCONTENT.style.width = gTotalWidth - margins[1] - margins[3];
            MAINCONTENT.style.height = gTotalHeight;
            gTotalHeight += margins[0] + margins[2];
        } catch (err) {}
    }

    str = System.Gadget.Settings.readString("Border");
    if (str == "")
        System.Gadget.Settings.write("Border", true);
    else {
        MAINCONTENT.style.borderStyle = System.Gadget.Settings.read("Border") ? gBorder : "none";
    }

    str = System.Gadget.Settings.readString("Server");
    if (str == "")
        System.Gadget.Settings.writeString("Server", gServer);
    else
        gServer = str;

    str = System.Gadget.Settings.readString("Port");
    if (str == "")
        System.Gadget.Settings.writeString("Port", gPort);
    else
        gPort = str;

    str = System.Gadget.Settings.readString("PIN");
    if (str == "")
        System.Gadget.Settings.writeString("PIN", gPIN);
    else
        gPIN = str;

    str = System.Gadget.Settings.readString("DateFormat");
    if (str == "")
        System.Gadget.Settings.writeString("DateFormat", gDateFormat);
    else
        gDateFormat = str;

    str = System.Gadget.Settings.readString("TimeFormat");
    if (str == "")
        System.Gadget.Settings.writeString("TimeFormat", gTimeFormat);
    else
        gTimeFormat = str;

    str = System.Gadget.Settings.readString("Update");
    if (str == "")
        System.Gadget.Settings.write("Update", gUpdateMinutes);
    else {
        try {
            gUpdateMinutes = parseInt(str);
            if (gUpdateMinutes < 1)
                gUpdateMinutes = 5;
        } catch (err) {
            gUpdateMinutes = 5;
        }
    }

    str = System.Gadget.Settings.readString("LaunchType");
    if (str == "")
        System.Gadget.Settings.writeString("LaunchType", "0");
    else {
        try {
            gLaunchType = parseInt(str);
            if (gLaunchType < 0 || gLaunchType > 3)
                gLaunchType = 0;
        } catch (err) {
            gLaunchType = 0;
        }
    }

    str = System.Gadget.Settings.readString("Logos");
    if (str == "")
        System.Gadget.Settings.write("Logos", false);
    else
        gShowLogos = (str == "True");

    str = System.Gadget.Settings.readString("Padding");
    if (str == "")
        System.Gadget.Settings.write("Padding", false);
    else
        gAddPadding = (str == "True");

    str = System.Gadget.Settings.readString("RecString5");
    if (str == "")
        System.Gadget.Settings.writeString("RecString5", gRecString);
    else
        gRecString = str;

    // Set up size
    document.body.style.height = gTotalHeight;
    document.body.style.width = gTotalWidth;
    RECORDCONTENT.style.height = gHeaderHeight + gRecHeight * gNumRecs;

    // Set up background
    BKGD.src = gBackgroundImg;
    BKGD.style.width = gTotalWidth;
    BKGD.style.height = gTotalHeight;

    // Update/connect in 3 seconds
    if (RECORDCONTENT.timer != null)
        clearTimeout(RECORDCONTENT.timer);
    RECORDCONTENT.timer = setInterval(ConnectAndSetTimer, 3000);
}

function ConnectAndSetTimer() {
    if (RECORDCONTENT.timer != null)
        clearTimeout(RECORDCONTENT.timer);
    RECORDCONTENT.timer = setInterval(ConnectToNPVR, gUpdateMinutes * 60 * 1000);

    ConnectToNPVR();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// For flyout
function ShowFlyout() {
    try {
        if (System.Gadget.Flyout.show) {
            System.Gadget.Flyout.show = false;
        } else {

            System.Gadget.Flyout.onShow = function() { SetFlyout(); }
            System.Gadget.Flyout.show = true;
        }
    } catch (err) {
        //PN.innerText = err.Description;
    }
}

function SetFlyout() {
    System.Gadget.Flyout.document.parentWindow.Init(gRecArray, gDateFormat, gTimeFormat, "http://" + gServer + ":" + gPort + DETAILS_URL);
    System.Gadget.Flyout.document.parentWindow.FillFlyoutSchedule(gShowLogos);
}

function ShowFlyout2() {
    try {
        if (System.Gadget.Flyout.show) {
            System.Gadget.Flyout.show = false;
        } else {

            System.Gadget.Flyout.onShow = function() { SetFlyout2(); }
            System.Gadget.Flyout.show = true;
        }
    } catch (err) {
        //PN.innerText = err.Description;
    }
}

function SetFlyout2() {
    System.Gadget.Flyout.document.parentWindow.FillSystemInfo(gInfoArray);
}

function GetInstallDirFromReg() {
    try {
        var shellobj = new ActiveXObject("WScript.Shell");
        return shellobj.RegRead(REG_INSTALL);
    } catch (Error) {
        try {
            var shellobj2 = new ActiveXObject("WScript.Shell");
            return shellobj2.RegRead(REG_INSTALL_64);
        } catch (Error2) {
            return "";
        }
    }
}

function HeaderRefresh() {
    CURRENTHEADER.innerText = REFRESH;
}

function HeaderNormal() {
    CURRENTHEADER.innerText = RECSCHEDULE;
}

function ReadLocalSettings() {

    var fs = new ActiveXObject("Scripting.FileSystemObject");
    try {
        var ts = fs.OpenTextFile(System.Gadget.path + "/settings.ini", 1);
        var ini = "";
        ini = ts.ReadAll();
        ts.Close();
    } catch (err) {
        return;
    }

    var lines = ini.split('\n');
    var lineCount = lines.length;

    var n = 0;

    while (n < lineCount - 1) {

        var str = lines[n];
        var key = str.substring(0, str.indexOf("="));
        var value = str.substring(str.indexOf("=") + 1, str.length);
        value = value.replace("\r", "");
        if (value == 'true') value = 'True';
        if (value == 'false') value = 'False';
        else System.Gadget.Settings.write(key, value);
        n++;
    }
}