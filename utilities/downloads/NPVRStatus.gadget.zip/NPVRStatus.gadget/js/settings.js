﻿// NextPVR Gadget v1.0

var BROWSE_FILTER = "Image Files:*.jpg;*.png;*.gif::";
var SETTINGS_SIZING = "?width=100&height=100";
var gImgFile = "";

function LoadSettings()
{
    System.Gadget.onSettingsClosing = SettingsClosing;
    ShowGroup(0);
    
    // Load from settings file
    gImgFile = System.Gadget.Settings.readString("Background");
    CHECKBORDER.checked = System.Gadget.Settings.read( "Border");
    MARGINSTEXT.value = System.Gadget.Settings.read( "Margins");
    SERVERTEXT.value = System.Gadget.Settings.read( "Server");
    PORTTEXT.value = System.Gadget.Settings.read("Port");
    PINTEXT.value = System.Gadget.Settings.readString("PIN");
    DATETEXT.value = System.Gadget.Settings.read( "DateFormat");
    TIMETEXT.value = System.Gadget.Settings.read( "TimeFormat");
    UPDATETEXT.value = System.Gadget.Settings.read( "Update");
    WIDTHTEXT.value = System.Gadget.Settings.read("Width");
    CHECKLOGOS.checked = System.Gadget.Settings.read("Logos");
    CHECKPADDING.checked = System.Gadget.Settings.read("Padding");
    CHECKDISK.checked = System.Gadget.Settings.read("ShowDisk");
    RSSTRINGTEXT.value = System.Gadget.Settings.read("RecString5");
    ITEMHEIGHTTEXT.value = System.Gadget.Settings.read("RecHeight");
    
    try
    {
        var tmp = parseInt( System.Gadget.Settings.readString( "LaunchType"));
        if( tmp < 0 || tmp > 3)
            tmp = 0;
        LAUNCHCOMBO.selectedIndex = tmp;
    }
    catch( err)
    {
        LAUNCHCOMBO.selectedindex = 0;   
    }
    
    try
    {
        var tmp = parseInt( System.Gadget.Settings.readString( "Size"));
        if( tmp < 1 || tmp > 12)
            tmp = 3;
        SIZECOMBO.selectedIndex = tmp-1;
    }
    catch( err)
    {
        SIZECOMBO.selectedindex = 2;   
    }
    
    // Set image
    LoadSettingsImage();
}

function SettingsClosing(event)
{
    if (event.closeAction == event.Action.commit)
    {
        // Write to settings file
        System.Gadget.Settings.write( "Background", gImgFile);
        System.Gadget.Settings.write( "Border", CHECKBORDER.checked);
        System.Gadget.Settings.write( "Margins", MARGINSTEXT.value);
        System.Gadget.Settings.write( "Server", SERVERTEXT.value);
        System.Gadget.Settings.write("Port", PORTTEXT.value);
        System.Gadget.Settings.writeString("PIN", PINTEXT.value);
        System.Gadget.Settings.write( "DateFormat", DATETEXT.value);
        System.Gadget.Settings.write( "TimeFormat", TIMETEXT.value);
        System.Gadget.Settings.write( "Update", UPDATETEXT.value);
        System.Gadget.Settings.write( "Width", WIDTHTEXT.value);
        System.Gadget.Settings.write( "LaunchType", LAUNCHCOMBO.selectedIndex);
        System.Gadget.Settings.write( "Size", SIZECOMBO.selectedIndex + 1);
        System.Gadget.Settings.write("Logos", CHECKLOGOS.checked);
        System.Gadget.Settings.write("Padding", CHECKPADDING.checked);
        System.Gadget.Settings.write("ShowDisk", CHECKDISK.checked);
        System.Gadget.Settings.write("RecString5", RSSTRINGTEXT.value);
        System.Gadget.Settings.write("RecHeight", ITEMHEIGHTTEXT.value);
        WriteLocalSettings()
    }
    event.cancel = false;
}

function LoadSettingsImage()
{
    CURIMAGE.src = "gimage:///" + gImgFile + SETTINGS_SIZING;
}


function BROWSE_onclick() 
{
    try
    {
        var index = gImgFile.lastIndexOf( '\\');
        var newFile = System.Shell.chooseFile( true, BROWSE_FILTER, gImgFile.slice(0,index), gImgFile.slice(index+1));
        if( newFile != null)
        {
            gImgFile = newFile.path;
            LoadSettingsImage();
         }
    }
    catch( err)
    {
        //IMAGETEXT.innerText = err.Description;
    }
}


function WriteLocalSettings() {
    DataArr = [];

    DataArr.push({ "Key": "Background", "Value": System.Gadget.Settings.read("Background") });
    DataArr.push({ "Key": "Border", "Value": System.Gadget.Settings.read("Border") });
    DataArr.push({ "Key": "Margins", "Value": System.Gadget.Settings.read("Margins") });
    DataArr.push({ "Key": "Server", "Value": System.Gadget.Settings.read("Server") });
    DataArr.push({ "Key": "Port", "Value": System.Gadget.Settings.read("Port") });
    DataArr.push({ "Key": "PIN", "Value": System.Gadget.Settings.readString("PIN") });
    DataArr.push({ "Key": "DateFormat", "Value": System.Gadget.Settings.read("DateFormat") });
    DataArr.push({ "Key": "TimeFormat", "Value": System.Gadget.Settings.read("TimeFormat") });
    DataArr.push({ "Key": "Update", "Value": System.Gadget.Settings.read("Update") });
    DataArr.push({ "Key": "Width", "Value": System.Gadget.Settings.read("Width") });
    DataArr.push({ "Key": "LaunchType", "Value": System.Gadget.Settings.read("LaunchType") });
    DataArr.push({ "Key": "Size", "Value": System.Gadget.Settings.read("Size") });
    DataArr.push({ "Key": "Logos", "Value": System.Gadget.Settings.read("Logos") });
    DataArr.push({ "Key": "Padding", "Value": System.Gadget.Settings.read("Padding") });
    DataArr.push({ "Key": "ShowDisk", "Value": System.Gadget.Settings.read("ShowDisk") });
    DataArr.push({ "Key": "RecString5", "Value": System.Gadget.Settings.read("RecString5") });
    DataArr.push({ "Key": "RecHeight", "Value": System.Gadget.Settings.read("RecHeight") });

    var fs = new ActiveXObject("Scripting.FileSystemObject");
    var newFile = fs.CreateTextFile(System.Gadget.path + "/settings.ini", true);

    for (i = 0; i < DataArr.length; i++)
        newFile.WriteLine(DataArr[i].Key + "=" + DataArr[i].Value);

    newFile.Close();
}

function ShowGroup(group) {
    GENERALGROUP.style.display = (group == 0) ? "block" : "none";
    DISPLAYGROUP.style.display = (group == 1) ? "block" : "none";
    RECGROUP.style.display = (group == 2) ? "block" : "none";
    HELPGROUP.style.display = (group == 3) ? "block" : "none";
}